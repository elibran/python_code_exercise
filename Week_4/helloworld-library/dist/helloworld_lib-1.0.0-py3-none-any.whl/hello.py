def say_hello():
    """Prints a greeting message."""
    print("Hello, World, from the Python package!")
    